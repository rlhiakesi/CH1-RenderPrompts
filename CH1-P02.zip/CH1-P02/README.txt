SBL 1.0 resolved page rendering package
Render target: CH1-P02
Entry file: CH1-P02.resolved.json

Rendering instruction:
Render the attached SBL page. Treat the SBL as the page specification and the supplied canonical assets as authoritative. Generate the complete manga page at the canvas dimensions declared in the SBL.

Resources copied:
  Assets/Alpha-Character-Sheet.png
  Assets/COG-table-production-sheet.png
  Assets/Terra-Expression-Sheet.png
  Assets/Thalassor-Character-Sheet.png
  Assets/Vortex-Character-Sheet.png
  Assets/Terra_Canonical_Character_Specification.txt
  Assets/Pyrael-Character-Sheet.png
  Assets/Nivara-Character-Sheet.png
  Assets/COG_Table_and_Chairs_Canonical_Production_Specification.txt
  Assets/Mortheus-Character-Sheet.png
  Assets/Verdania-Character-Sheet.png
  Assets/Aurelia-Character-Sheet.png
  Assets/Alpha-expression-sheet.png
  Assets/Terra-Character-Sheet.png
  Assets/Lunaria-Character-Sheet.png
  Assets/Alpha_Canonical_Character_Specification.txt

Visual continuity references:
  (none)

Specification/support files:
  specification/SBL_v1.0_AI_Specification.md
  specification/sbl-1.0-renderable.schema.json
