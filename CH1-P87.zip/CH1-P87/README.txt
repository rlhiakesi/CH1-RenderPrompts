SBL 1.0 resolved page rendering package
Render target: CH1-P87
Entry file: CH1-P87.resolved.json

Rendering instruction:
Render the attached SBL page. Treat the SBL as the page specification and the supplied canonical assets as authoritative. Generate the complete manga page at the canvas dimensions declared in the SBL.

Resources copied:
  Assets/Pyrael-Character-Sheet.png
  Assets/Nyssara-Expression-Sheet.png
  Assets/Verdania-Character-Sheet.png
  Assets/Alpha-expression-sheet.png
  Assets/Thalassor-Character-Sheet.png
  Assets/Joan-a-Character-Sheet.png
  Assets/Alpha_Canonical_Character_Specification.txt
  Assets/Terra-Character-Sheet.png
  Assets/Nivara-Character-Sheet.png
  Assets/Zorna_Canonical_Character_Specification.txt
  Assets/Terra-Expression-Sheet.png
  Assets/Nyssara-Character-Sheet.png
  Assets/Lucy-Character-Sheet.png
  Assets/Nyssara_Canonical_Character_Specification.txt
  Assets/Mortheus-Character-Sheet.png
  Assets/Zorna-Character-Sheet.png
  Assets/Lunaria-Character-Sheet.png
  Assets/Aurelia-Character-Sheet.png
  Assets/Lucy_Furrier_Canonical_Character_Specification.txt
  Assets/Zorna-Expression-Sheet.png
  Assets/Vortex-Character-Sheet.png
  Assets/Alpha-Character-Sheet.png
  Assets/Terra_Canonical_Character_Specification.txt

Visual continuity references:
  (none)

Specification/support files:
  specification/SBL_v1.0_AI_Specification.md
  specification/sbl-1.0-renderable.schema.json
