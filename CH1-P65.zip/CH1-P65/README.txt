SBL 1.0 resolved page rendering package
Render target: CH1-P65
Entry file: CH1-P65.resolved.json

Rendering instruction:
Render the attached SBL page. Treat the SBL as the page specification and the supplied canonical assets as authoritative. Generate the complete manga page at the canvas dimensions declared in the SBL.

Resources copied:
  Assets/Zorna_Canonical_Character_Specification.txt
  Assets/Lunaria-Character-Sheet.png
  Assets/Alpha-expression-sheet.png
  Assets/Thalassor-Character-Sheet.png
  Assets/Vortex-Character-Sheet.png
  Assets/Alpha-Character-Sheet.png
  Assets/Terra-Expression-Sheet.png
  Assets/Joan-a-Character-Sheet.png
  Assets/Nyssara_Canonical_Character_Specification.txt
  Assets/Zorna-Character-Sheet.png
  Assets/Pyrael-Character-Sheet.png
  Assets/Terra-Character-Sheet.png
  Assets/Terra_Canonical_Character_Specification.txt
  Assets/Nyssara-Expression-Sheet.png
  Assets/Verdania-Character-Sheet.png
  Assets/Aurelia-Character-Sheet.png
  Assets/Zorna-Expression-Sheet.png
  Assets/Nyssara-Character-Sheet.png
  Assets/Alpha_Canonical_Character_Specification.txt
  Assets/Nivara-Character-Sheet.png
  Assets/Mortheus-Character-Sheet.png

Visual continuity references:
  (none)

Specification/support files:
  specification/SBL_v1.0_AI_Specification.md
  specification/sbl-1.0-renderable.schema.json
