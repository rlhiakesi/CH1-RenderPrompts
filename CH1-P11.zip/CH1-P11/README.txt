SBL 1.0 resolved page rendering package
Render target: CH1-P11
Entry file: CH1-P11.resolved.json

Rendering instruction:
Render the attached SBL page. Treat the SBL as the page specification and the supplied canonical assets as authoritative. Generate the complete manga page at the canvas dimensions declared in the SBL.

Resources copied:
  Assets/Terra_Canonical_Character_Specification.txt
  Assets/Mortheus-Character-Sheet.png
  Assets/Zorna_Canonical_Character_Specification.txt
  Assets/Thalassor-Character-Sheet.png
  Assets/Terra-Expression-Sheet.png
  Assets/Alpha-expression-sheet.png
  Assets/Zorna-Expression-Sheet.png
  Assets/Pyrael-Character-Sheet.png
  Assets/Alpha-Character-Sheet.png
  Assets/Vortex-Character-Sheet.png
  Assets/Alpha_Canonical_Character_Specification.txt
  Assets/Verdania-Character-Sheet.png
  Assets/Zorna-Character-Sheet.png
  Assets/Joan-a-Character-Sheet.png
  Assets/Terra-Character-Sheet.png
  Assets/Lunaria-Character-Sheet.png
  Assets/Nivara-Character-Sheet.png
  Assets/Aurelia-Character-Sheet.png

Visual continuity references:
  (none)

Specification/support files:
  specification/SBL_v1.0_AI_Specification.md
  specification/sbl-1.0-renderable.schema.json
